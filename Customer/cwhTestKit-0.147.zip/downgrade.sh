#!/bin/bash

./start.sh "WesGilster/CWH-Reify3D" force