#!/bin/bash

cp -f config.properties.firstInstall ~/3dPrinters/config.properties
