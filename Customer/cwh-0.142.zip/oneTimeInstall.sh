#!/bin/bash

./nicInstall.sh